from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from database import SessionLocal, Product
from kafka_utils import publish_event

app = FastAPI()

class InventoryUpdate(BaseModel):
    product_id: str
    quantity: int

@app.get("/inventory")
def get_inventory():
    db = SessionLocal()
    products = db.query(Product).all()
    db.close()
    return [{"product_id": p.product_id, "quantity": p.quantity} for p in products]

@app.put("/inventory/admin")
def update_inventory(update: InventoryUpdate):
    db = SessionLocal()
    
    product = db.query(Product).filter(Product.product_id == update.product_id).first()
    
    if not product:
        db.close()
        raise HTTPException(status_code=404, detail="Product not found")
    
    old_quantity = product.quantity
    product.quantity = update.quantity
    db.commit()
    
    event = {
        "product_id": update.product_id,
        "old_quantity": old_quantity,
        "new_quantity": update.quantity,
        "action": "admin_update"
    }
    publish_event('inventory.admin.updated', event)
    
    db.close()
    return {"product_id": update.product_id, "quantity": update.quantity}
